@extends('dashbord.layouts.master')
@section('toolbar')
    <!--begin::Toolbar container-->
    <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
        <!--begin::Page title-->
        <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
            <!--begin::Title-->
            <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                {{trans('employee.create')}}</h1>
            <!--end::Title-->
            <!--begin::Breadcrumb-->
            <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">

                <li class="breadcrumb-item text-muted">
                    <a href="{{ route('admin.dashboard') }}" class="text-muted text-hover-primary">
                        {{trans('Toolbar.home')}}</a>
                </li>
                <li class="breadcrumb-item">
                    <span class="bullet bg-gray-400 w-5px h-2px"></span>
                </li>
                <li class="breadcrumb-item text-muted">
                    {{trans('Toolbar.site')}}
                </li>
                <li class="breadcrumb-item">
                    <span class="bullet bg-gray-400 w-5px h-2px"></span>
                </li>
                <li class="breadcrumb-item text-muted">
                    <a href="{{ route('admin.hr.employee.index') }}"
                       class="text-muted text-hover-primary"> {{trans('Toolbar.blog')}}</a>
                </li>
                <li class="breadcrumb-item">
                    <span class="bullet bg-gray-400 w-5px h-2px"></span>
                </li>
                <li class="breadcrumb-item text-muted">
                    {{trans('Toolbar.blogCreate')}}
                </li>


            </ul>
            <!--end::Breadcrumb-->
        </div>
        <!--begin::Actions-->
        <div class="d-flex align-items-center gap-2 gap-lg-3">
            <!--begin::Filter menu-->
            <div class="d-flex">
                <a href="{{route('admin.hr.employee.index')}}"
                   class="btn btn-icon btn-sm btn-primary flex-shrink-0 ms-4">

                    <!--begin::Svg Icon | path: /var/www/preview.keenthemes.com/keenthemes/keen/docs/core/html/src/media/icons/duotune/arrows/arr054.svg-->
                    <span class="svg-icon svg-icon-2">
                                   <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                       <path
                                           d="M17.6 4L9.6 12L17.6 20H13.6L6.3 12.7C5.9 12.3 5.9 11.7 6.3 11.3L13.6 4H17.6Z"
                                           fill="currentColor"/>
                                   </svg>
                                </span>
                    <!--end::Svg Icon-->
                </a>
            </div>
            <!--end::Filter menu-->
            <!--begin::Secondary button-->
            <!--end::Secondary button-->
            <!--begin::Primary button-->
            <!--end::Primary button-->
        </div>
        <!--end::Actions-->

    </div>
    <!--end::Toolbar container-->
@endsection

@section('content')

    <!--begin::Content container-->
    <div id="kt_app_content_container" class="app-container container-xxxl">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <form id="StorForm" class="form d-flex flex-column flex-lg-row "
              action="{{route('admin.hr.employee.update',$one_data->id)}}" method="post" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="_method" value="PATCH"/>

            <input type="hidden" name="id" value="{{$one_data->id}}">
            <!--begin::Aside column-->
            <div class="d-flex flex-column gap-7 gap-lg-10 w-100 w-lg-300px mb-7 me-lg-10">
                <!--begin::Thumbnail settings-->
                <div class="card card-flush py-4">
                    <!--begin::Card header-->
                    <div class="card-header">
                        <!--begin::Card title-->
                        <div class="card-title">
                            <h2>{{trans('employee.image')}}</h2>
                        </div>
                        <!--end::Card title-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body text-center pt-0">
                        <!--begin::Image input-->
                        <!--begin::Image input placeholder-->
                        <style>.image-input-placeholder {
                                background-image: url('{{$one_data->imageUrl}}');
                            }

                            [data-bs-theme="dark"] .image-input-placeholder {
                                background-image: url('{{$one_data->imageUrl}}');
                            }</style>
                        <!--end::Image input placeholder-->
                        <div class="mb-7">
                            <!--begin::Image input-->
                            <div
                                class="image-input image-input-empty image-input-outline image-input-placeholder mb-3"
                                data-kt-image-input="true">
                                <!--begin::Preview existing avatar-->
                                <div class="image-input-wrapper w-150px h-150px"></div>
                                <!--end::Preview existing avatar-->
                                <!--begin::Label-->
                                <label
                                    class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                    data-kt-image-input-action="change" data-bs-toggle="tooltip"
                                    title="Change avatar">
                                    <!--begin::Icon-->
                                    <i class="bi bi-pencil-fill fs-7"></i>
                                    <!--end::Icon-->
                                    <!--begin::Inputs-->
                                    <input type="file" name="image" accept=".png, .jpg, .jpeg"/>
                                    <input type="hidden" name="avatar_remove"/>
                                    <!--end::Inputs-->
                                </label>
                                <!--end::Label-->
                                <!--begin::Cancel-->
                                <span
                                    class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                    data-kt-image-input-action="cancel" data-bs-toggle="tooltip"
                                    title="Cancel avatar">
															<i class="bi bi-x fs-2"></i>
														</span>
                                <!--end::Cancel-->
                                <!--begin::Remove-->
                                <span
                                    class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                    data-kt-image-input-action="remove" data-bs-toggle="tooltip"
                                    title="Remove avatar">
															<i class="bi bi-x fs-2"></i>
														</span>
                                <!--end::Remove-->
                            </div>

                            <!--end::Image input-->
                            <!--begin::Description-->
                            <div class="text-muted fs-7">Set the category thumbnail image. Only *.png, *.jpg
                                and
                                *.jpeg image files are accepted
                            </div>
                            <!--end::Description-->
                        </div>

                        @error('image')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <!--end::Card body-->
                </div>
                <!--end::Thumbnail settings-->
                <div class="card card-flush py-4">
                    <!--begin::Card header-->

                    <!--begin::Card body-->
                    <div class="card-body text-center pt-0">
                        <div class="row g-9 mb-7">
                            <!--begin::Col-->
                            <div class="">
                                <!--begin::Label-->
                                <label
                                    class="required fs-6 fw-semibold mb-2">{{trans('employee.phone')}}</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="tel"
                                       class="form-control  @error('phone') is-invalid @enderror"
                                       value="{{old('phone',$one_data->phone)}}" name="phone"
                                       placeholder="" id="phone"/>
                                <!--end::Input-->
                                @error('phone')
                                <div
                                    class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="">
                                <!--begin::Label-->
                                <label
                                    class="required fs-6 fw-semibold mb-2">{{trans('employee.email')}}</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="email"
                                       class="form-control  @error('email') is-invalid @enderror"
                                       placeholder=""
                                       name="email" value="{{old('email',$one_data->email)}}">
                                <!--end::Input-->
                                @error('email')
                                <div
                                    class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <!--end::Col-->
                        </div>

                    </div>
                </div>

            </div>
            <!--end::Aside column-->
            <!--begin::Main column-->
            <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10">
                <!--begin::General options-->
                <div class="card card-flush py-4">
                    <!--begin::Card header-->
                    <div class="card-header">
                        <div class="card-title">
                            <h2>{{trans('employee.mainData')}}</h2>
                        </div>
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body pt-0">
                        <div class="row">
                            <!--begin::Input group-->
                            <div class="mb-10 col  fv-row">
                                <!--begin::Label-->
                                <label class="required form-label">{{trans('employee.name')}}</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="text" name="name"
                                       class="form-control mb-2  @error('name') is-invalid @enderror"
                                       placeholder="Product name" value="{{old('name',$one_data->name)}}"/>
                                <!--end::Input-->
                                @error('name')
                                <div class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="mb-10 col  fv-row">
                                <!--begin::Label-->
                                <label class="required form-label">{{trans('employee.national_id')}} </label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="number" name="national_id"
                                       class="form-control mb-2  @error('national_id') is-invalid @enderror"
                                       placeholder="Product name" value="{{old('national_id',$one_data->national_id)}}"/>
                                <!--end::Input-->
                                @error('national_id')
                                <div class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <!--begin::Col-->
                            <div class="mb-10 col ">
                                <!--begin::Label-->
                                <label
                                    class="required fs-6 fw-semibold mb-2">{{trans('employee.birthday')}}</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="text"
                                       class="form-control  @error('birthday') is-invalid @enderror"
                                       value="{{old('birthday',$one_data->birthday)}}" name="birthday"
                                       placeholder="" id="birthday"/>
                                <!--end::Input-->
                                @error('phone')
                                <div
                                    class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <!--end::Col-->
                            <!--end::Input group-->
                        </div>

                        <div class="row">
                            <!--begin::Col-->
                            <div class="mb-10 col-4 ">
                                <!--begin::Label-->
                                <label
                                    class="required fs-6 fw-semibold mb-2">{{trans('employee.date_hired')}}</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="text"
                                       class="form-control  @error('date_hired') is-invalid @enderror"
                                       placeholder="" name="date_hired" id="date_hired" value="{{old('date_hired',$one_data->date_hired)}}">
                                <!--end::Input-->
                                @error('date_hired')
                                <div class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="mb-10 col-8 ">
                                <!--begin::Label-->
                                <label
                                    class="required fs-6 fw-semibold mb-2">{{trans('employee.address')}}</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="text"
                                       class="form-control  @error('address') is-invalid @enderror"
                                       placeholder="" name="address" value="{{old('address',$one_data->address)}}">
                                <!--end::Input-->
                                @error('address')
                                <div class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                        </div>
                        <div class="row">
                            <!--end::Col-->
                            <div class="mb-10 col  fv-row">
                                <!--begin::Label-->
                                <label class="required form-label">{{trans('employee.experience_year')}}</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="number" name="experience_year"
                                       class="form-control mb-2  @error('experience_year') is-invalid @enderror"
                                       placeholder="experience_year" value="{{old('experience_year',$one_data->experience_year)}}"/>
                                <!--end::Input-->
                                @error('experience_year')
                                <div class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="mb-10 col  fv-row">
                                <!--begin::Label-->
                                <label class="required form-label">{{trans('employee.holiday_emergency')}} </label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="number" name="holiday_emergency"
                                       class="form-control mb-2  @error('holiday_emergency') is-invalid @enderror"
                                       placeholder="holiday_emergency" value="{{old('holiday_emergency',$one_data->holiday_emergency)}}"/>
                                <!--end::Input-->
                                @error('holiday_emergency')
                                <div class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <!--begin::Col-->
                            <div class="mb-10 col ">
                                <!--begin::Label-->
                                <label
                                    class="required fs-6 fw-semibold mb-2">{{trans('employee.holiday_year')}}</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="number"
                                       class="form-control  @error('holiday_year') is-invalid @enderror"
                                       value="{{old('holiday_year',$one_data->holiday_year)}}" name="holiday_year"
                                       placeholder="" id="holiday_year"/>
                                <!--end::Input-->
                                @error('holiday_year')
                                <div
                                    class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                        </div>
                        <div class="row">
                            <!--begin::Input group-->
                            <div class="mb-10 col  fv-row">
                                <!--begin::Label-->
                                <label class="required form-label">{{trans('employee.job_title')}}</label>
                                <!--end::Label-->
                                <select class="form-select mb-2 @error('job_title') is-invalid @enderror"
                                        data-control="select2" data-hide-search="false"
                                        data-placeholder="Select an option"
                                        id="job_title" name="job_title">

                                    <option>- {{trans('forms.select')}} -</option>
                                    @foreach($jop_title as $row)
                                        <option value="{{ $row->id }}"
                                        @if($one_data->job_title==$row->id) {{'selected'}} @endif
                                        >{{ $row->title }}</option>
                                    @endforeach
                                </select>
                                @error('job_title')
                                <div class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="mb-10 col  fv-row">
                                <!--begin::Label-->
                                <label class="required form-label">{{trans('employee.social_status')}}</label>
                                <!--end::Label-->
                                <select class="form-select mb-2 @error('social_status') is-invalid @enderror"
                                        data-control="select2" data-hide-search="false"
                                        data-placeholder="Select an option"
                                        id="social_status" name="social_status">

                                    <option>- {{trans('forms.select')}} -</option>
                                    @foreach($social_status as $row)
                                        <option value="{{ $row->id }}"
                                        @if($one_data->social_status==$row->id) {{'selected'}} @endif
                                        >{{ $row->title }}</option>
                                    @endforeach
                                </select>
                                @error('social_status')
                                <div class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="mb-10 col  fv-row">
                                <!--begin::Label-->
                                <label class="required form-label">{{trans('employee.specialization')}}</label>
                                <!--end::Label-->
                                <select class="form-select mb-2 @error('specialization') is-invalid @enderror"
                                        data-control="select2" data-hide-search="false"
                                        data-placeholder="Select an option"
                                        id="specialization" name="specialization">

                                    <option>- {{trans('forms.select')}} -</option>
                                    @foreach($specialization as $row)
                                        <option value="{{ $row->id }}" @if($one_data->specialization==$row->id) {{'selected'}} @endif>{{ $row->title }}</option>
                                    @endforeach
                                </select>
                                @error('specialization')
                                <div class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <!--end::Input group-->

                        </div>

                        <div class="row ">
                            <!--begin::Col-->
                            <div class="mb-10 col  fv-row">
                                <!--begin::Label-->
                                <label
                                    class="required fs-6 fw-semibold mb-2">{{trans('employee.main_salary')}}</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="number"
                                       class="form-control  @error('main_salary') is-invalid @enderror"
                                       value="{{old('main_salary',$one_data->main_salary)}}" name="main_salary"
                                       placeholder="" id="main_salary"/>
                                <!--end::Input-->
                                @error('main_salary')
                                <div
                                    class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="mb-10 col  fv-row">
                                <!--begin::Label-->
                                <label
                                    class="required fs-6 fw-semibold mb-2">{{trans('employee.work_hour_day')}}</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="email"
                                       class="form-control  @error('work_hour_day') is-invalid @enderror"
                                       placeholder="" name="work_hour_day" value="{{old('work_hour_day',$one_data->work_hour_day)}}">
                                <!--end::Input-->
                                @error('work_hour_day')
                                <div class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="mb-10 col  fv-row">
                                <!--begin::Label-->
                                <label
                                    class="required fs-6 fw-semibold mb-2">{{trans('employee.work_month_day')}}</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="email"
                                       class="form-control  @error('work_month_day') is-invalid @enderror"
                                       placeholder="" name="work_month_day" value="{{old('work_month_day',$one_data->work_month_day)}}">
                                <!--end::Input-->
                                @error('work_month_day')
                                <div class="fv-plugins-message-container invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                    <!--end::Card header-->
                </div>
                <!--end::General options-->

                <div class="d-flex justify-content-end">
                    <!--begin::Button-->
                    <button type="reset" class="btn btn-light me-5">{{trans('forms.cancel_btn')}}</button>
                    <!--end::Button-->
                    <!--begin::Button-->
                    <button type="submit" id="" class="btn btn-primary">
                        <span class="indicator-label">{{trans('forms.save_btn')}}</span>
                        <span class="indicator-progress">Please wait...
													<span
                                                        class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                    </button>
                    <!--end::Button-->
                </div>
            </div>
            <!--end::Main column-->
        </form>
    </div>
    <!--end::Content container-->

@endsection
@section('js')



    <script type="text/javascript" src="{{ asset('vendor/jsvalidation/js/jsvalidation.js')}}"></script>

    {!! JsValidator::formRequest('App\Http\Requests\hr\employee\UpdateRequest', '#StorForm') !!}
    <script>
        var KTAppBlogSave = function () {

            // Init daterangepicker
            const initDaterangepicker = () => {

                $("#date_hired").daterangepicker({
                    singleDatePicker: true,
                    showDropdowns: true,
                    minYear: 2000,
                    maxYear: parseInt(moment().format("YYYY"), 12),
                    minDate: '{{date('m/d/Y')}}',
                    autoApply: true


                });
                $("#birthday").daterangepicker({
                        singleDatePicker: true,
                        showDropdowns: true,
                        minYear: 1980,
                        maxYear: parseInt(moment().format("YYYY"), 12),
                        maxDate: '{{date('m/d/Y')}}',
                        autoApply: true

                    }
                );
            }
            // Public methods
            return {
                init: function () {
                    // Init forms
                    initDaterangepicker();
                }
            };
        }();
        // On document ready
        KTUtil.onDOMContentLoaded(function () {
            KTAppBlogSave.init();
        });
    </script>
@endsection

