<?php


use App\Http\Controllers\Api\AppDataController;
use App\Http\Controllers\Api\Member\OprationController;
use App\Http\Controllers\Api\Member\UsersApiController;
use App\Http\Controllers\Api\Settings;
use App\Http\Controllers\Api\Trainers\ScheduleController;
use App\Http\Controllers\Api\Trainers\TrainersController;
use App\Http\Controllers\Api\ApiComplaints;

use Illuminate\Support\Facades\Route;





